





// Siparişlerin örnek verileri
const orders = [
    { tarih: '2023-08-01', adres: 'İzmir, Türkiye', urunler: [
        { ad: 'Lavanta Yağı', aciklama: 'Doğal lavanta yağı, rahatlatıcı etkisi ile bilinir.', resim: 'img/products/product2/1.jpg', fiyat: '220.90' },
        { ad: 'Lavanta Sabunu', aciklama: 'Cilt için nemlendirici ve ferahlatıcı lavanta sabunu.', resim: 'img/products/product1/1.jpg', fiyat: '39.90'}
    ], durum: 'Hazırlanıyor' },
    { tarih: '2023-08-02', adres: 'İzmir, Türkiye', urunler: [
        { ad: 'Lavanta Şampuanı', aciklama: 'Saçları besleyen ve saç derisini rahatlatan lavanta şampuanı.', resim: 'img/products/product3/1.jpg', fiyat: '75.25' }
    ], durum: 'Kargoda' },
    { tarih: '2023-08-03', adres: 'İzmir, Türkiye', urunler: [
        { ad: 'Lavanta Çayı', aciklama: 'Stresli anlarda sakinleştirici etkisiyle bilinen lavanta çayı.', resim: 'img/products/product4/1.jpg', fiyat: '239.90' }
    ], durum: 'Teslim Edildi' }
];

// Siparişleri sayfada listeleme fonksiyonu
function listOrders() {
    const orderList = document.getElementById('order-list');

    // Her sipariş için tabloya yeni satır ekleme
    orders.forEach(order => {
        const row = document.createElement('tr');
        let productsHTML = '';
        let totalPrice = 0; // Toplam fiyatı hesaplamak için

        // Ürünleri tabloya eklemek için iç içe döngü
        order.urunler.forEach(product => {
            productsHTML += `
                <li class="product-item">
                    <img src="${product.resim}" alt="${product.ad}" class="product-image">
                    <div class="product-info">
                        <div class="product-name">${product.ad}</div>
                        <div class="product-description">${product.aciklama}</div>
                        <div class="product-price">$${product.fiyat}</div>
                    </div>
                </li>
            `;

            // Toplam fiyatı güncelle
            totalPrice += parseFloat(product.fiyat);
        });

        row.innerHTML = `
            <td>${order.tarih}</td>
            <td>${order.adres}</td>
            <td>
                <ul class="products-list">${productsHTML}</ul>
            </td>
            <td>$${totalPrice.toFixed(2)}</td>
            <td>${order.durum}</td>
        `;
        orderList.appendChild(row);
    });
}

// Sayfa yüklendiğinde siparişleri listele
document.addEventListener('DOMContentLoaded', listOrders);